(define-package "html2org" "20231203.951" "Convert html to org format text"
  '((emacs "24.4"))
  :commit "5481bf5875429bf8d21a2b7f028121158bedf66d" :authors
  '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers
  '(("洪筱冰" . "hxb@localhost.localdomain"))
  :maintainer
  '("洪筱冰" . "hxb@localhost.localdomain")
  :keywords
  '("convenience" "html" "org")
  :url "https://github.com/hxb2012/html2org.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
