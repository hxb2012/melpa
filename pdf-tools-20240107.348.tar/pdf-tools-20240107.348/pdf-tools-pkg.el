(define-package "pdf-tools" "20240107.348" "Support library for PDF documents"
  '((emacs "26.3")
    (tablist "1.0")
    (let-alist "1.0.4"))
  :commit "48c3440023dacdbad928f989c3b0bce7512a802c" :authors
  '(("Andreas Politz" . "mail@andreas-politz.de"))
  :maintainers
  '(("Vedang Manerikar" . "vedang.manerikar@gmail.com"))
  :maintainer
  '("Vedang Manerikar" . "vedang.manerikar@gmail.com")
  :keywords
  '("files" "multimedia")
  :url "http://github.com/vedang/pdf-tools/")
;; Local Variables:
;; no-byte-compile: t
;; End:
