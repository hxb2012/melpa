(define-package "sqlite-backport" "20231126.405" "Backport SQLite database access from Emacs 29"
  '((emacs "25.1"))
  :commit "c5cca33e2dd2360c0f6d81064f86a4a266cfe4a2" :authors
  '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers
  '(("洪筱冰" . "hxb@localhost.localdomain"))
  :maintainer
  '("洪筱冰" . "hxb@localhost.localdomain")
  :keywords
  '("sqlite")
  :url "https://github.com/hxb2012/sqlite-backport")
;; Local Variables:
;; no-byte-compile: t
;; End:
