(define-package "remu" "20231224.417" "Org Mode侧栏"
  '((emacs "29.0")
    (org "9.6"))
  :commit "74a9a43ac6e56dbfb1c1a883e312126a4951eea7" :authors
  '(("Jethro Kuan <jethrokuan95@gmail.com>, Carsten Dominik" . "carsten.dominik@gmail.com"))
  :maintainers
  '(("洪筱冰" . "hxb@localhost.localdomain"))
  :maintainer
  '("洪筱冰" . "hxb@localhost.localdomain")
  :keywords
  '("org")
  :url "https://github.com/hxb2012/remu")
;; Local Variables:
;; no-byte-compile: t
;; End:
