(define-package "orb" "20231231.238" "保存Org节点到SQLite"
  '((emacs "29.0")
    (org "9.6"))
  :commit "5a6f791f5888aa9014e52466f55e0ed11b2b10ab" :authors
  '(("Jethro Kuan <jethrokuan95@gmail.com>, Michael Albinus <michael.albinus@gmx.de>, Eric Schulte, Carsten Dominik" . "carsten.dominik@gmail.com"))
  :maintainers
  '(("洪筱冰" . "hxb@localhost.localdomain"))
  :maintainer
  '("洪筱冰" . "hxb@localhost.localdomain")
  :keywords
  '("org")
  :url "https://github.com/hxb2012/orb")
;; Local Variables:
;; no-byte-compile: t
;; End:
