(define-package "html2org" "20231224.415" "Convert html to org format text"
  '((emacs "24.4"))
  :commit "617136b09b60d852ea833b3074fa828206f0237a" :authors
  '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers
  '(("洪筱冰" . "hxb@localhost.localdomain"))
  :maintainer
  '("洪筱冰" . "hxb@localhost.localdomain")
  :keywords
  '("convenience" "html" "org")
  :url "https://github.com/hxb2012/html2org.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
