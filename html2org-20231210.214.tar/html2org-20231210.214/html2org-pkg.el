(define-package "html2org" "20231210.214" "Convert html to org format text"
  '((emacs "24.4"))
  :commit "a9b934317365d7400637981f03cc14a15b7a00f3" :authors
  '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers
  '(("洪筱冰" . "hxb@localhost.localdomain"))
  :maintainer
  '("洪筱冰" . "hxb@localhost.localdomain")
  :keywords
  '("convenience" "html" "org")
  :url "https://github.com/hxb2012/html2org.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
