;;; html2org.el --- Convert html to org format text   -*- coding: utf-8; lexical-binding: t; -*-

;; Copyright (C) 2017-2018 DarkSun

;; Author: DarkSun <lujun9972@gmail.com>
;; Maintainer: 洪筱冰 <hxb@localhost.localdomain>
;; URL: https://github.com/hxb2012/html2org.el
;; Created: 2017-4-10
;; Version: 0.1
;; Keywords: convenience, html, org
;; Package-Requires: ((emacs "24.4"))

;; This file is NOT part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Source code
;;
;; html2org's code can be found here:
;;   http://github.com/lujun9972/html2org.el


;;; Commentary:
;;

;;; Code:

(defvar html2org--entities nil)
(defvar html2org--base)
(defvar html2org--paragraph-start)
(defvar html2org--mark)
(defvar html2org--escape-braces)
(defvar html2org--code-start)
(defvar html2org--no-line-break)
(defvar html2org--item-style)
(defvar html2org--item-indent)
(defvar html2org--item-start)
(defvar html2org--desc-start)

(defconst html2org--braces '(("{" . "\uFE5B") ("}" . "\uFE5C")))

(defun html2org-string (string)
  (replace-regexp-in-string "[ \r\n\t]+" " " string))

(defun html2org-escape-string (string)
  (let ((s (if html2org--escape-braces
               (replace-regexp-in-string
                (string-join (mapcar 'regexp-quote (mapcar 'car html2org--braces)) "\\|")
                (lambda (c) (assoc-default c html2org--braces))
                string)
             string)))
    (replace-regexp-in-string
     (string-join (mapcar 'regexp-quote (hash-table-keys html2org--entities)) "\\|")
     (lambda (c) (regexp-quote (gethash c html2org--entities)))
     (html2org-string s))))

(defun html2org-finish-paragraph ()
  (when html2org--paragraph-start
    (save-excursion
      (goto-char html2org--paragraph-start)
      (skip-chars-forward " \t")
      (delete-region html2org--paragraph-start (point)))
    (save-excursion
      (replace-regexp-in-region
       (concat "[ \t]*" (regexp-quote "\\\\\n") "[ \t]*")
       (regexp-quote (concat "\\\\\n" html2org--item-indent))
       html2org--paragraph-start
       (point)))
    (delete-space--internal " \t" nil)
    (save-excursion
      (replace-regexp-in-region "\\([^ \t]\\)\u200C" "\\1" html2org--paragraph-start (point))
      (replace-regexp-in-region " \t+" " " html2org--paragraph-start (point))
      (replace-regexp-in-region "\t+ " " " html2org--paragraph-start (point))
      (replace-regexp-in-region "\t+" "\u200B" html2org--paragraph-start (point)))
    (with-restriction html2org--paragraph-start (point)
      (unless (eq (point-min) (point-max))
        (font-lock-ensure)
        (org-fill-paragraph)))
    (setq html2org--paragraph-start
          (when (eq (marker-position html2org--paragraph-start) (point))
            (insert html2org--item-indent)
            (point-marker)))))

(defun html2org-finish-mark (start mark)
  (insert "\t")
  (list
   (save-excursion
     (goto-char start)
     (skip-chars-forward " \t")
     (insert "\t")
     (insert mark)
     (point))
   (save-excursion
     (skip-chars-backward " \t")
     (save-excursion
       (insert mark))
     (point))))

(defun html2org-escape-code ()
  (apply
   'replace-regexp-in-region
   (concat "\\([^ \n\t]\\)" (regexp-quote "~ "))
   "\\1\u200B~ "
   (html2org-finish-mark html2org--code-start "~")))

(defun html2org-transform-mark (body mark)
  (let ((start (point-marker))
        (html2org--mark (cons mark html2org--mark)))
    (dolist (elem body)
      (html2org-transform-inline elem))
    (html2org-finish-mark start mark)))

(defun html2org-transform-group (body)
  (let ((start (point-marker))
        (html2org--escape-braces t))
    (dolist (elem body)
      (html2org-transform-inline elem))
    (save-excursion
      (goto-char start)
      (delete-space--internal " \t" nil)
      (insert "{"))
    (delete-space--internal " \t" nil)
    (insert "}")))

(defun html2org-transform-code (body)
  (dolist (elem body)
    (pcase elem
      ((pred stringp)
       (insert (html2org-string elem)))
      (`(br ,attrs . ,body)
       (html2org-escape-code)
       (insert "\\\\\n")
       (setq html2org--code-start (point)))
      (`(,tag ,attrs . ,body)
       (html2org-transform-code body)))))

(defun html2org-transform-inline (dom)
  (pcase dom
    ((pred stringp)
     (insert (html2org-escape-string dom)))
    ((or `(code ,attrs . ,body)
         `(samp ,attrs . ,body)
         `(kbd ,attrs . ,body))
     (let ((html2org--code-start (point-marker)))
       (html2org-transform-code body)
       (html2org-escape-code)))
    ((and (or `(b ,attrs . ,body)
              `(strong ,attrs . ,body))
          (guard (not (member "*" html2org--mark))))
     (html2org-transform-mark body "*"))
    ((and (or `(i ,attrs . ,body)
              `(em ,attrs . ,body)
              `(cite ,attrs . ,body)
              `(dfn ,attrs . ,body)
              `(var ,attrs . ,body))
          (guard (not (member "/" html2org--mark))))
     (html2org-transform-mark body "/"))
    ((and (or `(u ,attrs . ,body)
              `(ins ,attrs . ,body))
          (guard (not (member "_" html2org--mark))))
     (html2org-transform-mark body "_"))
    ((and (or `(s ,attrs . ,body)
              `(del ,attrs . ,body))
          (guard (not (member "+" html2org--mark))))
     (html2org-transform-mark body "+"))
    (`(sup ,attrs . , body)
     (insert "\u200C^")
     (html2org-transform-group body))
    (`(sub ,attrs . , body)
     (insert "\u200C_")
     (html2org-transform-group body))
    (`(br ,attrs . ,body)
     (if html2org--no-line-break
         (insert " ")
       (insert "\\\\\n")))
    (`(style ,attrs . ,body)
     (insert " "))
    (`(wbr ,attrs . ,body)
     (insert "\u200B"))
    (`(picture ,attrs . ,body)
     (html2org-transform-inline (dom-child-by-tag dom 'img)))
    ((and `(img ,attrs . ,body)
          (let `(src . ,src) (assoc 'src attrs)))
     (insert "[[")
     (insert (url-expand-file-name src html2org--base))
     (when-let ((alt (assoc 'alt attrs)))
       (insert "][")
       (insert (cdr alt)))
     (insert "]]"))
    ((and `(a ,attrs . ,body)
          (let `(href . ,href) (assoc 'href attrs)) (guard body))
     (insert "[[")
     (insert (url-expand-file-name href html2org--base))
     (insert "][")
     (html2org-transform-inline-body body)
     (insert "]]"))
    ((and `(span ,attrs . ,body)
          (let `(class . "mwe-math-element") (assoc 'class attrs))
          (let `(img ,imgattrs . ,imgbody) (dom-child-by-tag dom 'img))
          (let `(alt . ,alt) (assoc 'alt imgattrs)))
     (insert (format "\\(%s\\)" alt)))
   (`(,tag ,attrs . ,body)
     (dolist (elem body)
       (html2org-transform-inline elem)))))

(defun html2org-tranform-inline-no-line-break (body)
  (let ((html2org--no-line-break t))
    (dolist (elem body)
      (html2org-transform-inline elem))))

(defun html2org-transform-inline-body (body)
  (insert
   (with-temp-buffer
     (let ((html2org--paragraph-start (point-marker))
           (html2org--mark nil)
           (html2org--escape-braces nil)
           (html2org--item-style nil)
           (html2org--item-indent "")
           (html2org--item-start nil)
           (html2org--desc-start nil))
       (html2org-tranform-inline-no-line-break body)
       (html2org-finish-paragraph))
     (buffer-substring-no-properties (point-min) (point-max)))))

(defun html2org-ensure-paragraph ()
  (unless html2org--paragraph-start
    (insert "\n\n")
    (insert html2org--item-indent)
    (setq html2org--paragraph-start (point-marker))))

(defun html2org-clear-paragraph ()
  (when (and html2org--paragraph-start
             (not (eq (marker-position html2org--paragraph-start) (point))))
    (html2org-finish-paragraph)))

(defun html2org-start-paragraph ()
  (html2org-clear-paragraph)
  (html2org-ensure-paragraph))

(defun html2org-transform-heading (mark body)
  (html2org-start-paragraph)
  (insert mark)
  (setq html2org--paragraph-start (point-marker))
  (html2org-tranform-inline-no-line-break body)
  (html2org-finish-paragraph))

(defun html2org-start-item ()
  (if (and html2org--item-start
           (eq html2org--item-start html2org--paragraph-start))
      (progn
        (html2org-finish-paragraph)
        (delete-space--internal " \t" nil)
        (insert "\n")
        (insert html2org--item-indent)
        (setq html2org--paragraph-start (point-marker)))
    (html2org-start-paragraph)))

(defun html2org-transform-list (style body)
  (html2org-start-item)
  (let ((html2org--item-style style))
    (dolist (elem body)
      (pcase elem
        (`(li ,attrs . ,body)
         (html2org-transform-block elem)))))
  (html2org-finish-paragraph))

(defun html2org-transform-desc (body)
  (html2org-start-item)
  (let ((html2org--item-style "- ")
        (html2org--desc-start nil))
    (dolist (elem body)
      (pcase elem
        (`(dt ,attrs . ,body)
         (if html2org--paragraph-start
             (when (equal html2org--desc-start html2org--paragraph-start)
               (html2org-finish-paragraph)
               (insert "\n"))
           (insert "\n"))
         (insert html2org--item-indent)
         (insert html2org--item-style)
         (html2org-tranform-inline-no-line-break body)
         (html2org-finish-paragraph)
         (insert " :: ")
         (setq html2org--paragraph-start (point-marker))
         (setq html2org--desc-start html2org--paragraph-start))
        (`(dd ,attrs . ,body)
         (let ((html2org--item-indent
                (concat
                 html2org--item-indent
                 (make-string (length html2org--item-style) ? ))))
           (html2org-start-paragraph)
           (dolist (elem body)
             (html2org-transform-block elem))
           (html2org-finish-paragraph))))))
  (html2org-finish-paragraph))

(defun html2org-transform-rows (tbody)
  (pcase-dolist (`(tr ,attrs . ,children) (dom-children tbody))
    (pcase-dolist (`(,tag ,attrs . ,body) children)
      (when (or (eq tag 'th) (eq tag 'td))
        (insert "|")
        (insert " ")
        (html2org-transform-inline-body body)
        (insert " ")))
    (insert "|\n")
    (insert html2org--item-indent)))

(defun html2org-transform-block (dom)
  (pcase dom
    (`(p ,attrs . ,body)
     (html2org-start-paragraph)
     (dolist (elem body)
       (html2org-transform-inline elem))
     (html2org-finish-paragraph))
    (`(hr ,attrs . ,body)
     (html2org-start-item)
     (insert "-----")
     (setq html2org--paragraph-start nil))
    (`(blockquote ,attrs . ,body)
     (html2org-start-item)
     (insert "#+BEGIN_QUOTE\n")
     (let ((html2org--paragraph-start (point-marker))
           (html2org--item-style nil)
           (html2org--item-indent "")
           (html2org--item-start nil)
           (html2org--desc-start nil))
       (dolist (elem body)
         (html2org-transform-block elem))
       (html2org-finish-paragraph))
     (insert "\n")
     (insert html2org--item-indent)
     (insert "#+END_QUOTE")
     (setq html2org--paragraph-start nil))
    (`(dialog ,attrs . ,body)
     (html2org-start-item)
     (insert "#+BEGIN_CENTER\n")
     (let ((html2org--paragraph-start (point-marker))
           (html2org--item-style nil)
           (html2org--item-indent "")
           (html2org--item-start nil)
           (html2org--desc-start nil))
       (dolist (elem body)
         (html2org-transform-block elem))
       (html2org-finish-paragraph))
     (insert "\n")
     (insert html2org--item-indent)
     (insert "#+END_CENTER")
     (setq html2org--paragraph-start nil))
    (`(pre ,attrs . ,body)
     (html2org-start-item)
     (insert "#+BEGIN_EXAMPLE\n")
     (insert (string-trim (dom-texts dom "") "[\n]" "[\n]"))
     (insert "\n")
     (insert html2org--item-indent)
     (insert "#+END_EXAMPLE")
     (setq html2org--paragraph-start nil))
    (`(table ,attrs . ,body)
     (html2org-start-item)
     (when-let ((caption (dom-child-by-tag dom 'caption)))
       (insert "#+CAPTION: ")
       (insert (string-trim (html2org-string (dom-texts caption))))
       (insert "\n")
       (insert html2org--item-indent))
     (when-let ((tbody (dom-child-by-tag dom 'tbody)))
       (when-let ((thead (dom-child-by-tag dom 'thead)))
         (html2org-transform-rows thead)
         (insert html2org--item-indent)
         (insert "|-\n")
         (insert html2org--item-indent))
       (html2org-transform-rows tbody)
       (when-let ((tfoot (dom-child-by-tag dom 'tfoot)))
         (insert "|-\n")
         (insert html2org--item-indent)
         (html2org-transform-rows tfoot))
       (org-table-align))
     (delete-all-space)
     (setq html2org--paragraph-start nil))
    (`(figure ,attrs . ,body)
     (html2org-start-item)
     (when-let ((caption (dom-child-by-tag dom 'figcaption)))
       (insert "#+CAPTION: ")
       (insert (string-trim (html2org-string (dom-texts caption))))
       (insert "\n")
       (insert html2org--item-indent))
     (when-let ((img (dom-child-by-tag dom 'img)))
       (html2org-transform-inline img))
     (delete-all-space)
     (setq html2org--paragraph-start nil))
    (`(dl ,attrs . ,body)
     (html2org-transform-desc body))
    ((or `(ul ,attrs . ,body)
         `(menu ,attrs . ,body))
     (html2org-transform-list "- " body))
    (`(ol ,attrs . ,body)
     (html2org-transform-list "1. " body))
    ((and `(li ,attrs . ,body)
          (guard html2org--item-style))
     (unless html2org--paragraph-start
       (insert "\n")
       (insert html2org--item-indent))
     (insert html2org--item-style)
     (setq html2org--paragraph-start (point-marker))
     (let ((html2org--item-start html2org--paragraph-start)
           (html2org--item-indent
            (concat
             html2org--item-indent
             (make-string (length html2org--item-style) ? ))))
       (dolist (elem body)
         (html2org-transform-block elem))
       (html2org-finish-paragraph)))
    ((and `(div ,attrs . ,body)
          (let `"mwe-math-element" (dom-attr dom 'class))
          (let `(img ,imgattrs . ,imgbody) (dom-child-by-tag dom 'img))
          (let `(alt . ,alt) (assoc 'alt imgattrs)))
     (html2org-start-paragraph)
     (insert (format "\\begin{equation}\n%s\n\\end{equation}" alt))
     (html2org-finish-paragraph))
    ((and `(div ,attrs . ,body)
          (let (rx "mw-highlight mw-highlight-lang-"
                   (let lang (+ (not space)))
                   (* anything))
            (dom-attr dom 'class))
          (let `,pre (dom-child-by-tag dom 'pre))
          (guard pre))
     (html2org-start-item)
     (insert (format "#+BEGIN_SRC %s\n" lang))
     (insert (string-trim (dom-texts pre "") "[\n]" "[\n]"))
     (insert "\n")
     (insert html2org--item-indent)
     (insert "#+END_SRC"))
    ((and `(div ,attrs . ,body)
          (let (rx (? (seq (* anything) space))
                   "highlight-"
                   (let lang (+ (not space)))
                   (* anything))
            (dom-attr dom 'class))
          (let `,div (dom-child-by-tag dom 'div))
          (let "highlight" (dom-attr div 'class))
          (let `,pre (dom-child-by-tag div 'pre))
          (guard pre))
     (html2org-start-item)
     (insert (format "#+BEGIN_SRC %s\n" lang))
     (insert (string-trim (dom-texts pre "") "[\n]" "[\n]"))
     (insert "\n")
     (insert html2org--item-indent)
     (insert "#+END_SRC"))
    ((or `(li ,attrs . ,body)
         `(dt ,attrs . ,body)
         `(dd ,attrs . ,body)
         `(div ,attrs . ,body)
         `(main ,attrs . ,body)
         `(header ,attrs . ,body)
         `(footer ,attrs . ,body)
         `(nav ,attrs . ,body)
         `(aside ,attrs . ,body)
         `(article ,attrs . ,body)
         `(section ,attrs . ,body)
         `(address ,attrs . ,body)
         `(hgroup ,attrs . ,body)
         `(form ,attrs . ,body)
         `(fieldset ,attrs . ,body)
         `(details ,attrs . ,body))
     (html2org-start-paragraph)
     (dolist (elem body)
       (html2org-transform-block elem))
     (html2org-finish-paragraph))
    (_
     (html2org-ensure-paragraph)
     (html2org-transform-inline dom))))

(defun html2org-transform (dom)
  (pcase dom
    (`(html ,attrs . ,body)
     (html2org-transform (dom-child-by-tag dom 'body)))
    (`(body ,attrs . ,body)
     (dolist (elem body)
       (html2org-transform elem)))
    (`(h1 ,attrs . ,body)
     (html2org-transform-heading "** " body))
    (`(h2 ,attrs . ,body)
     (html2org-transform-heading "*** " body))
    (`(h3 ,attrs . ,body)
     (html2org-transform-heading "**** " body))
    (`(h4 ,attrs . ,body)
     (html2org-transform-heading "***** " body))
    (`(h5 ,attrs . ,body)
     (html2org-transform-heading "****** " body))
    (`(h6 ,attrs . ,body)
     (html2org-transform-heading "******* " body))
    (_
     (html2org-transform-block dom))))

(defun html2org--init-entities ()
  (setq html2org--entities (make-hash-table :test 'equal))
  (pcase-dolist (`(,name ,_ ,_ ,html ,_ ,_ ,utf8) org-entities)
    (when (and (eq (length utf8) 1)
               (not (string-match "[*/_+~^{}<>|]" name))
               (> (string-to-char utf8) 127))
      (unless (gethash utf8 html2org--entities)
        (puthash utf8 (format "\\%s{}" name) html2org--entities)))
    (when (and (eq (length html) 1)
               (string-match "[*/_+~^{}<>|]" html))
      (unless (gethash html html2org--entities)
        (puthash html (format "\\%s{}" name) html2org--entities)))))

;;;###autoload
(defun html2org (start end &optional replace url)
  "Convert HTML to org text between START and END.

If REPLACE is nil, it just return the converted org content
without change the buffer; Otherwise, it replace the orgin
content with converted org content."
  (interactive "r\nP")
  (let ((dom (libxml-parse-html-region start end))
        (buffer (current-buffer)))
    (with-temp-buffer
      (org-mode)
      (setq-local org-pretty-entities t)
      (unless html2org--entities
        (html2org--init-entities))
      (let ((temp-buffer (current-buffer))
            (html2org--base url)
            (html2org--paragraph-start (point-marker))
            (html2org--mark nil)
            (html2org--escape-braces nil)
            (html2org--no-line-break nil)
            (html2org--item-style nil)
            (html2org--item-indent "")
            (html2org--item-start nil)
            (html2org--desc-start nil))
        (html2org-transform dom)
        (html2org-clear-paragraph)
        (if replace
            (with-current-buffer buffer
              (delete-region start end)
              (insert
               (with-current-buffer temp-buffer
                 (buffer-substring-no-properties (point-min) (point-max)))))
          (message "%s" (buffer-substring-no-properties (point-min) (point-max))))))))

(provide 'html2org)
;;; html2org.el ends here
