(define-package "html2org" "20231217.216" "Convert html to org format text"
  '((emacs "24.4"))
  :commit "6c5d82bf281048002ef400b63ee322ed7ddb00c9" :authors
  '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers
  '(("洪筱冰" . "hxb@localhost.localdomain"))
  :maintainer
  '("洪筱冰" . "hxb@localhost.localdomain")
  :keywords
  '("convenience" "html" "org")
  :url "https://github.com/hxb2012/html2org.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
